import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";


import { Observable } from "rxjs/internal/Observable";
@Injectable({
  providedIn: 'root'
})
export class InventoryServiceService {

  constructor(private httpClient: HttpClient) {} 

baseUrl = 'http://localhost:8070/produc';


  public showMerchants(): Observable<any> {
   
    return this.httpClient.get<any>("http://localhost:8070/getdetails");
  }



  public showProducts(mid): Observable<any> {

    console.log(mid);
    return this.httpClient.get<any>(`${this.baseUrl}/${mid}` );
  }
  
 
}

