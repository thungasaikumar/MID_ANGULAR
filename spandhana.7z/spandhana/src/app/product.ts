export class product
{
 id:number;
 mid:number;
 name: string;
 brand: string;
 description:string;
 model: string;
 price: string;
 custfeed: string;
 
}